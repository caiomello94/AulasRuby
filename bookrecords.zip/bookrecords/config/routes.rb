Rails.application.routes.draw do
  resources :posts
    root "home#index"


  get "/home", to: "home#index"
  get "home/:id", to: "home#show"


end
