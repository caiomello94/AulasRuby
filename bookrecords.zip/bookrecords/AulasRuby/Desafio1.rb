


# colocando nome e definindo a mesma usando gets.chomp.
print "Digite seu nome: "
nome = gets.chomp


#colocando sobrenome e definindo a mesma usando gets.chomp.

print  "Digite seu sobrenome: "
sobrenome = gets.chomp

#perguntando qual a idade e definindo a mesma usando gets.chomp.
print "Qual a sua idade: "
idade = gets.chomp


#demostrando tudo digitado em tela

puts "Seu nome é #{nome} #{sobrenome},e sua idade é #{idade}! "
